import { useState, useCallback, useEffect, useRef } from 'react';
import FileUpload from './components/FileUpload';
import TrackChangesPanel from './components/TrackChangesPanel';
import DocxViewer from './components/DocxViewer';
import PdfViewer from './components/PdfViewer';
import PxmlEditor from './components/PxmlEditor';
import { parseDocxFile } from './docxParser';
import { parseExcelFile, matchExcelToTrackChanges } from './excelParser';
import type { ParsedDocx, TrackChange, ChunkMatch, ExcelValidationMap, ExcelMetaMap, ValidityFilter } from './types';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { MatchDetail } from './excelParser';
import './DocxViewerApp.css';

const API_URL = '';

type ViewerMode = 'docx' | 'pdf';

interface SessionMeta {
  session_id: string;
  session_name: string;
  created_at: number;
  updated_at: number;
  docx_filename: string;
  pxml_filename: string;
  excel_filename: string | null;
  pdf_filename: string | null;
  current_revision_index: number;
  total_revisions: number;
  total_invalid: number;
  revision_statuses: Record<string, string>;
  completed_count?: number;
  progress_text?: string;
}

function DocxViewerApp() {
  const [parsedDocx, setParsedDocx] = useState<ParsedDocx | null>(null);
  const [docxFile, setDocxFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedChange, setSelectedChange] = useState<TrackChange | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pxmlContent, setPxmlContent] = useState<string>('');
  const [matches, setMatches] = useState<ChunkMatch[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [viewerMode, setViewerMode] = useState<ViewerMode>('docx');

  // Excel / filter state
  const [validationMap, setValidationMap] = useState<ExcelValidationMap>({});
  const [metaMap, setMetaMap] = useState<ExcelMetaMap>({});
  const [matchDetails, setMatchDetails] = useState<MatchDetail[]>([]);
  const [excelFileName, setExcelFileName] = useState<string | null>(null);
  const [validityFilter, setValidityFilter] = useState<ValidityFilter>('all');
  const [unmappedRevisions, setUnmappedRevisions] = useState<TrackChange[]>([]);

  // Session state
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [currentRevisionIndex, setCurrentRevisionIndex] = useState(0);
  const [revisionStatuses, setRevisionStatuses] = useState<Record<string, string>>({});
  const [recentSessions, setRecentSessions] = useState<SessionMeta[]>([]);
  const [showRecentSessions, setShowRecentSessions] = useState(true);
  const [savingPxml, setSavingPxml] = useState(false);
  const [sessionPdfUrl, setSessionPdfUrl] = useState<string | null>(null);

  // Theme toggle (dark / light)
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try { return (localStorage.getItem('vv-theme') as 'dark' | 'light') || 'dark'; } catch { return 'dark'; }
  });
  useEffect(() => { document.documentElement.setAttribute('data-theme', theme); localStorage.setItem('vv-theme', theme); }, [theme]);



  // Resizable left panel
  const [leftPanelWidth, setLeftPanelWidth] = useState(320);
  const isDragging = useRef(false);
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    const startX = e.clientX;
    const startW = leftPanelWidth;
    const onMove = (ev: MouseEvent) => {
      if (!isDragging.current) return;
      const newW = Math.min(Math.max(startW + (ev.clientX - startX), 220), 600);
      setLeftPanelWidth(newW);
    };
    const onUp = () => { isDragging.current = false; document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }, [leftPanelWidth]);

  // Resizable right (PXML) panel
  const [rightPanelWidth, setRightPanelWidth] = useState(380);
  const isDraggingRight = useRef(false);
  const handleRightMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDraggingRight.current = true;
    const startX = e.clientX;
    const startW = rightPanelWidth;
    const onMove = (ev: MouseEvent) => {
      if (!isDraggingRight.current) return;
      // Dragging left grows the panel (startX - ev.clientX), dragging right shrinks it
      const newW = Math.min(Math.max(startW + (startX - ev.clientX), 280), 900);
      setRightPanelWidth(newW);
    };
    const onUp = () => { isDraggingRight.current = false; document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }, [rightPanelWidth]);

  const [pxmlFileName, setPxmlFileName] = useState<string | null>(null);

  // Get emp_id from localStorage (set by main app's AuthContext on login)
  const getEmpId = (): string => {
    try {
      const stored = localStorage.getItem('user_profile');
      if (stored) {
        const profile = JSON.parse(stored);
        return profile.emp_id || '';
      }
    } catch { /* ignore */ }
    return '';
  };

  // Load recent sessions on mount + check URL for ?session=xxx to auto-resume
  useEffect(() => {
    fetchRecentSessions();

    // Check if URL has a session parameter to auto-resume
    const params = new URLSearchParams(window.location.search);
    const urlSessionId = params.get('session');
    if (urlSessionId) {
      // Fetch session meta and auto-resume
      fetch(`${API_URL}/api/validation/session/${urlSessionId}`)
        .then(res => { if (res.ok) return res.json(); throw new Error('not found'); })
        .then((meta: SessionMeta) => { resumeSession(meta); })
        .catch(() => { /* session not found, show landing */ });
    }
  }, []);

  const fetchRecentSessions = async () => {
    try {
      const res = await fetch(`${API_URL}/api/validation/sessions`);
      if (res.ok) {
        const data = await res.json();
        setRecentSessions(data.sessions || []);
      }
    } catch { /* ignore */ }
  };

  // Create a session on the backend when files are uploaded
  const createSession = async (docx: File, pxml: File, excel?: File, pdf?: File) => {
    const form = new FormData();
    form.append('docx_file', docx);
    form.append('pxml_file', pxml);
    if (excel) form.append('excel_file', excel);
    if (pdf) form.append('pdf_file', pdf);
    form.append('session_name', docx.name);
    form.append('emp_id', getEmpId());

    try {
      const res = await fetch(`${API_URL}/api/validation/create-session`, { method: 'POST', body: form });
      if (res.ok) {
        const meta: SessionMeta = await res.json();
        setSessionId(meta.session_id);
        setRevisionStatuses(meta.revision_statuses || {});
        setCurrentRevisionIndex(meta.current_revision_index || 0);
        setShowRecentSessions(false);
        // Save to localStorage for quick access
        localStorage.setItem('lastSessionId', meta.session_id);
        return meta;
      }
    } catch (err) {
      console.error('Failed to create session:', err);
    }
    return null;
  };

  // Resume a session
  const resumeSession = async (session: SessionMeta) => {
    setIsLoading(true);
    setError(null);
    setShowRecentSessions(false);
    setSessionId(session.session_id);
    setRevisionStatuses(session.revision_statuses || {});
    setCurrentRevisionIndex(session.current_revision_index || 0);
    localStorage.setItem('lastSessionId', session.session_id);

    // Reset PXML state so PxmlEditor gets clean initial props on each resume
    setPxmlContent('');
    setPxmlFileName(null);

    // Set session PDF URL BEFORE loading the DOCX so that PdfViewer's conversion
    // effect sees it and skips re-conversion when docxFile state updates.
    if (session.pdf_filename) {
      const pdfSessionUrl = `${API_URL}/api/validation/session/${session.session_id}/file/${session.pdf_filename}`;
      setSessionPdfUrl(pdfSessionUrl);
    } else {
      setSessionPdfUrl(null);
    }

    try {
      // Load DOCX
      let docxResult: ParsedDocx | null = null;
      const docxRes = await fetch(`${API_URL}/api/validation/session/${session.session_id}/file/${session.docx_filename}`);
      if (docxRes.ok) {
        const blob = await docxRes.blob();
        const file = new File([blob], session.docx_filename, { type: blob.type });
        const result = await parseDocxFile(file);
        docxResult = result;
        setParsedDocx(result);
        setDocxFile(file);
        setFileName(session.docx_filename);

        // Auto-select the current revision
        if (result.trackChanges[session.current_revision_index]) {
          setSelectedChange(result.trackChanges[session.current_revision_index]);
        }

        // Report total revisions to backend
        await fetch(`${API_URL}/api/validation/set-total-revisions`, {
          method: 'POST',
          body: new URLSearchParams({ session_id: session.session_id, total_revisions: String(result.trackChanges.length) }),
        });
      }

      // Load PXML
      if (session.pxml_filename) {
        const pxmlRes = await fetch(`${API_URL}/api/validation/session/${session.session_id}/file/${session.pxml_filename}`);
        if (pxmlRes.ok) {
          const text = await pxmlRes.text();
          setPxmlContent(text);
          setPxmlFileName(session.pxml_filename);
        }
      }

      // Load Excel if present
      if (session.excel_filename) {
        const excelRes = await fetch(`${API_URL}/api/validation/session/${session.session_id}/file/${session.excel_filename}`);
        if (excelRes.ok) {
          const blob = await excelRes.blob();
          const file = new File([blob], session.excel_filename, { type: blob.type });
          setExcelFileName(session.excel_filename);
          // Parse and match against the docx we just loaded
          if (docxResult) {
            const rows = await parseExcelFile(file);
            const { validationMap: vMap, metaMap: mMap, matchDetails: details, unmappedRevisions: unmapped } = matchExcelToTrackChanges(rows, docxResult.trackChanges);
            setValidationMap(vMap);
            setMetaMap(mMap);
            setMatchDetails(details);
            setUnmappedRevisions(unmapped);

            // Send invalid count to backend so session card shows completed/invalid
            const invalidCount = Object.values(vMap).filter(v => v === false).length;
            await fetch(`${API_URL}/api/validation/set-total-revisions`, {
              method: 'POST',
              body: new URLSearchParams({
                session_id: session.session_id,
                total_revisions: String(docxResult.trackChanges.length),
                total_invalid: String(invalidCount),
              }),
            });
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resume session');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelect = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);
    setSelectedChange(null);
    setMatches([]);

    try {
      const result = await parseDocxFile(file);
      setParsedDocx(result);
      setDocxFile(file);
      setFileName(file.name);
      setShowRecentSessions(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse DOCX file');
      setParsedDocx(null);
      setDocxFile(null);
      setFileName(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleExcelSelect = useCallback(async (file: File) => {
    if (!parsedDocx) {
      setError('Please upload a DOCX file first.');
      return;
    }
    try {
      setError(null);
      const excelRows = await parseExcelFile(file);
      const { validationMap: vMap, metaMap: mMap, matchDetails: details, unmappedRevisions: unmapped } = matchExcelToTrackChanges(excelRows, parsedDocx.trackChanges);
      setValidationMap(vMap);
      setMetaMap(mMap);
      setMatchDetails(details);
      setUnmappedRevisions(unmapped);
      setExcelFileName(file.name);

      // Send invalid count to backend so session card shows completed/invalid
      if (sessionId && parsedDocx) {
        const invalidCount = Object.values(vMap).filter(v => v === false).length;
        fetch(`${API_URL}/api/validation/set-total-revisions`, {
          method: 'POST',
          body: new URLSearchParams({
            session_id: sessionId,
            total_revisions: String(parsedDocx.trackChanges.length),
            total_invalid: String(invalidCount),
          }),
        }).catch(() => {});
      }

      // If no session yet, create one now
      if (!sessionId && docxFile) {
        await createSession(docxFile, new File([pxmlContent], fileName?.replace('.docx', '.pxml') || 'doc.pxml'), file);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse Excel file');
    }
  }, [parsedDocx, sessionId, docxFile, pxmlContent, fileName]);

  const handlePxmlLoaded = useCallback((content: string) => {
    setPxmlContent(content);
    // If we have a DOCX loaded but no session yet, create one
    if (docxFile && !sessionId) {
      const pxmlFile = new File([content], fileName?.replace('.docx', '.pxml') || 'document.pxml');
      createSession(docxFile, pxmlFile);
    }
  }, [docxFile, sessionId, fileName]);

  // Save PXML to backend
  const handleSavePxml = useCallback(async (content: string) => {
    setPxmlContent(content);
    if (!sessionId) return;
    setSavingPxml(true);
    try {
      await fetch(`${API_URL}/api/validation/save-pxml`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, pxml_content: content }),
      });
    } catch (err) {
      console.error('Failed to save PXML:', err);
    } finally {
      setSavingPxml(false);
    }
  }, [sessionId]);

  const handleSelectChange = useCallback((change: TrackChange) => {
    setSelectedChange((prev) => (prev?.id === change.id ? null : change));
  }, []);

  // Navigation
  const handleNavigate = useCallback((index: number) => {
    setCurrentRevisionIndex(index);
    // Persist position to backend
    if (sessionId) {
      fetch(`${API_URL}/api/validation/update-position`, {
        method: 'POST',
        body: new URLSearchParams({ session_id: sessionId, current_revision_index: String(index) }),
      }).catch(() => {});
    }
  }, [sessionId]);

  // Mark revision complete
  const handleMarkComplete = useCallback(async (index: number) => {
    const newStatuses = { ...revisionStatuses, [String(index)]: 'complete' };
    setRevisionStatuses(newStatuses);

    // Advance to next
    const total = parsedDocx?.trackChanges.length ?? 0;
    let nextIdx = index + 1;
    while (nextIdx < total && newStatuses[String(nextIdx)] === 'complete') nextIdx++;
    if (nextIdx < total) {
      setCurrentRevisionIndex(nextIdx);
      if (parsedDocx?.trackChanges[nextIdx]) {
        setSelectedChange(parsedDocx.trackChanges[nextIdx]);
      }
    }

    if (sessionId) {
      try {
        await fetch(`${API_URL}/api/validation/update-revision-status`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId, revision_index: index, status: 'complete' }),
        });
      } catch { /* ignore */ }
    }
  }, [revisionStatuses, sessionId, parsedDocx]);

  // Mark revision skipped
  const handleMarkSkipped = useCallback(async (index: number) => {
    const newStatuses = { ...revisionStatuses, [String(index)]: 'skipped' };
    setRevisionStatuses(newStatuses);

    const total = parsedDocx?.trackChanges.length ?? 0;
    let nextIdx = index + 1;
    while (nextIdx < total && (newStatuses[String(nextIdx)] === 'complete' || newStatuses[String(nextIdx)] === 'skipped')) nextIdx++;
    if (nextIdx < total) {
      setCurrentRevisionIndex(nextIdx);
      if (parsedDocx?.trackChanges[nextIdx]) {
        setSelectedChange(parsedDocx.trackChanges[nextIdx]);
      }
    }

    if (sessionId) {
      try {
        await fetch(`${API_URL}/api/validation/update-revision-status`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId, revision_index: index, status: 'skipped' }),
        });
      } catch { /* ignore */ }
    }
  }, [revisionStatuses, sessionId, parsedDocx]);

  const handleParagraphClick = useCallback(async (paragraphIndex: number) => {
    if (!parsedDocx || !pxmlContent) return;
    const contextText = parsedDocx.paragraphs[paragraphIndex].runs.map((r) => r.text).join('');
    if (!contextText.trim()) return;

    setIsSearching(true);
    setMatches([]);
    try {
      const response = await fetch(`${API_URL}/api/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context_text: contextText, pxml_content: pxmlContent, chunk_size: 500, overlap_percent: 0.3 }),
      });
      if (!response.ok) throw new Error('Backend search failed');
      const data = await response.json();
      setMatches(data.matches || []);
    } catch (err) {
      console.error('Search error:', err);
      setMatches([]);
    } finally {
      setIsSearching(false);
    }
  }, [parsedDocx, pxmlContent]);

  const handleTextSearch = useCallback(async (text: string) => {
    if (!pxmlContent || !text.trim()) return;
    setIsSearching(true);
    setMatches([]);
    try {
      const response = await fetch(`${API_URL}/api/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context_text: text, pxml_content: pxmlContent, chunk_size: 500, overlap_percent: 0.3 }),
      });
      if (!response.ok) throw new Error('Backend search failed');
      const data = await response.json();
      setMatches(data.matches || []);
    } catch (err) {
      console.error('Text search error:', err);
      setMatches([]);
    } finally {
      setIsSearching(false);
    }
  }, [pxmlContent]);

  // Filter track changes
  const filteredTrackChanges = (parsedDocx?.trackChanges ?? []).filter((tc) => {
    // Always hide formatting changes
    if (tc.type === 'formatChange') return false;
    if (validityFilter === 'all') return true;
    if (!(tc.id in validationMap)) return false;
    if (validityFilter === 'true') return validationMap[tc.id] === true;
    if (validityFilter === 'false') return validationMap[tc.id] === false;
    return true;
  });

  // ─── Recent Sessions View ────────────────────
  if (showRecentSessions && !parsedDocx) {
    return (
      <div className="app">
        <div className="app-header">
          <h1>📋 Visual Validator</h1>
          <FileUpload onFileSelect={handleFileSelect} isLoading={isLoading} fileName={fileName} />
        </div>
        {error && <div className="error-bar">{error}</div>}
        <div className="recent-sessions-view">
          <div className="sessions-intro">
            <h2>Welcome Back</h2>
            <p>Resume a previous validation session or upload new files to start.</p>
          </div>
          {recentSessions.length > 0 ? (
            <div className="sessions-grid">
              {recentSessions.map((s) => (
                <div key={s.session_id} className="session-card" onClick={() => resumeSession(s)}>
                  <div className="session-card-header">
                    <span className="session-name">{s.session_name}</span>
                    <span className="session-progress">{s.progress_text || '0/0'}</span>
                  </div>
                  <div className="session-card-meta">
                    <span>📄 {s.docx_filename}</span>
                    {s.excel_filename && <span>📊 {s.excel_filename}</span>}
                  </div>
                  <div className="session-card-footer">
                    <span className="session-date">
                      Last edited: {new Date(s.updated_at * 1000).toLocaleDateString()} {new Date(s.updated_at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="no-sessions">
              <p>No recent sessions. Upload a DOCX file to begin.</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ─── Main Viewer ─────────────────────────────
  return (
    <div className="app">
      <div className="app-header">
        <h1>📋 Visual Validator</h1>
        <FileUpload onFileSelect={handleFileSelect} isLoading={isLoading} fileName={fileName} />
        <div className="viewer-mode-toggle">
          <label className={`mode-option ${viewerMode === 'docx' ? 'active' : ''}`}>
            <input type="checkbox" checked={viewerMode === 'docx'} onChange={() => setViewerMode('docx')} />
            <span>📝 DOCX</span>
          </label>
          <label className={`mode-option ${viewerMode === 'pdf' ? 'active' : ''}`}>
            <input type="checkbox" checked={viewerMode === 'pdf'} onChange={() => setViewerMode('pdf')} />
            <span>📄 PDF</span>
          </label>
        </div>
        <button
          className="btn-theme-toggle"
          onClick={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {theme === 'dark' ? '☀️' : '🌙'}
        </button>
        {sessionId && (
          <span className="session-indicator" title={`Session: ${sessionId}`}>
            {savingPxml ? '💾 Saving...' : '🟢 Saved'}
          </span>
        )}
        <button className="btn-sessions" onClick={() => { setShowRecentSessions(true); setParsedDocx(null); setPxmlContent(''); setPxmlFileName(null); }} title="Back to sessions">
          📂
        </button>
      </div>

      {error && <div className="error-bar">{error}</div>}

      <div className="panels-container">
        <div className="panel panel-left" style={{ width: leftPanelWidth, minWidth: 220 }}>
          <TrackChangesPanel
            trackChanges={filteredTrackChanges}
            allTrackChangesCount={parsedDocx?.trackChanges.length ?? 0}
            onSelectChange={handleSelectChange}
            selectedChangeId={selectedChange?.id ?? null}
            validityFilter={validityFilter}
            onFilterChange={setValidityFilter}
            validationMap={validationMap}
            metaMap={metaMap}
            onExcelSelect={handleExcelSelect}
            excelFileName={excelFileName}
            matchDetails={matchDetails}
            unmappedRevisions={unmappedRevisions}
            currentRevisionIndex={currentRevisionIndex}
            onNavigate={handleNavigate}
            revisionStatuses={revisionStatuses}
            onMarkComplete={handleMarkComplete}
            onMarkSkipped={handleMarkSkipped}
          />
        </div>
        <div className="panel-resize-handle" onMouseDown={handleMouseDown} />
        <div className="panel panel-center">
          <div style={{ display: viewerMode === 'docx' ? 'contents' : 'none' }}>
            <DocxViewer
              paragraphs={parsedDocx?.paragraphs ?? []}
              selectedChange={selectedChange}
              onParagraphClick={handleParagraphClick}
            />
          </div>
          <div style={{ display: viewerMode === 'pdf' ? 'contents' : 'none' }}>
            <PdfViewer
              selectedChange={selectedChange}
              onTextSearch={handleTextSearch}
              docxFile={docxFile}
              sessionPdfUrl={sessionPdfUrl}
              sessionId={sessionId}
            />
          </div>
        </div>
        <div className="panel-resize-handle" onMouseDown={handleRightMouseDown} />
        <div className="panel panel-right" style={{ width: rightPanelWidth, minWidth: 280 }}>
          <PxmlEditor
            onPxmlLoaded={handlePxmlLoaded}
            onPxmlSaved={handleSavePxml}
            matches={matches}
            isSearching={isSearching}
            sessionId={sessionId}
            initialContent={pxmlContent}
            initialFileName={pxmlFileName}
          />
        </div>
      </div>
    </div>
  );
}

export default DocxViewerApp;
