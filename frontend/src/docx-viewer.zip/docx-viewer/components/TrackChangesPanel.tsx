import React, { useRef, useState } from 'react';
import type { TrackChange, ExcelValidationMap, ExcelMetaMap, ValidityFilter } from '../types';
import type { MatchDetail } from '../excelParser';
import './TrackChangesPanel.css';

interface Props {
  trackChanges: TrackChange[];
  allTrackChangesCount: number;
  onSelectChange: (change: TrackChange) => void;
  selectedChangeId: string | null;
  validityFilter: ValidityFilter;
  onFilterChange: (filter: ValidityFilter) => void;
  validationMap: ExcelValidationMap;
  metaMap: ExcelMetaMap;
  onExcelSelect: (file: File) => void;
  excelFileName: string | null;
  matchDetails: MatchDetail[];
  unmappedRevisions: TrackChange[];
  // Session / navigation props
  currentRevisionIndex: number;
  onNavigate: (index: number) => void;
  revisionStatuses: Record<string, string>;
  onMarkComplete: (index: number) => void;
  onMarkSkipped: (index: number) => void;
}

const TrackChangesPanel: React.FC<Props> = ({
  trackChanges,
  allTrackChangesCount,
  onSelectChange,
  selectedChangeId,
  validityFilter,
  onFilterChange,
  validationMap,
  metaMap,
  onExcelSelect,
  excelFileName,
  matchDetails,
  unmappedRevisions,
  currentRevisionIndex,
  onNavigate,
  revisionStatuses,
  onMarkComplete,
  onMarkSkipped,
}) => {
  const excelInputRef = useRef<HTMLInputElement>(null);
  const [showMatchInfo, setShowMatchInfo] = useState(false);
  const [activePopover, setActivePopover] = useState<{ type: 'reason' | 'suggestedFix' } | null>(null);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'insertion': return '➕';
      case 'deletion': return '➖';
      case 'formatChange': return '🔄';
      case 'moveTo': return '📥';
      case 'moveFrom': return '📤';
      default: return '•';
    }
  };

  const getTypeClass = (type: string) => {
    switch (type) {
      case 'insertion': return 'change-insertion';
      case 'deletion': return 'change-deletion';
      case 'formatChange': return 'change-format';
      case 'moveTo': return 'change-move-to';
      case 'moveFrom': return 'change-move-from';
      default: return '';
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return dateStr;
    }
  };

  const handleExcelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onExcelSelect(file);
    e.target.value = '';
  };

  const completedCount = Object.values(revisionStatuses).filter(s => s === 'complete').length;
  const totalCount = trackChanges.length;
  const currentChange = trackChanges[currentRevisionIndex] || null;
  const currentStatus = revisionStatuses[String(currentRevisionIndex)] || 'pending';

  const matchedCount = matchDetails.filter((d) => d.matched).length;
  const unmatchedCount = matchDetails.filter((d) => !d.matched).length;

  // Navigate and auto-select the change
  const goTo = (idx: number) => {
    if (idx >= 0 && idx < totalCount) {
      onNavigate(idx);
      if (trackChanges[idx]) {
        onSelectChange(trackChanges[idx]);
      }
    }
  };

  // Go to next incomplete revision
  const goToNextIncomplete = () => {
    for (let i = currentRevisionIndex + 1; i < totalCount; i++) {
      if (revisionStatuses[String(i)] !== 'complete') {
        goTo(i);
        return;
      }
    }
    for (let i = 0; i < currentRevisionIndex; i++) {
      if (revisionStatuses[String(i)] !== 'complete') {
        goTo(i);
        return;
      }
    }
  };

  return (
    <div className="track-changes-panel">
      {/* Progress bar header */}
      <div className="panel-header">
        <h3>📋 Revisions</h3>
        <span className="progress-badge">
          {completedCount}/{totalCount}
        </span>
      </div>

      {/* Progress bar */}
      <div className="progress-bar-container">
        <div
          className="progress-bar-fill"
          style={{ width: totalCount > 0 ? `${(completedCount / totalCount) * 100}%` : '0%' }}
        />
        <span className="progress-bar-text">
          {totalCount > 0 ? `${Math.round((completedCount / totalCount) * 100)}%` : '0%'} complete
        </span>
      </div>

      {/* Excel upload + filter section */}
      <div className="filter-section">
        <div className="excel-upload-row">
          <button className="btn-excel-upload" onClick={() => excelInputRef.current?.click()}>
            📊 Upload Excel
          </button>
          <input ref={excelInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleExcelChange} hidden />
          {excelFileName && <span className="excel-filename" title={excelFileName}>{excelFileName}</span>}
        </div>

        {excelFileName && (
          <>
            <div className="filter-row">
              <span className="filter-label">Filter:</span>
              <select className="filter-dropdown" value={validityFilter} onChange={(e) => onFilterChange(e.target.value as ValidityFilter)}>
                <option value="all">All</option>
                <option value="true">✔ Valid</option>
                <option value="false">✗ Invalid</option>
              </select>
            </div>
            <div className="match-summary">
              <span className="match-stat matched">✔ {matchedCount}</span>
              {unmatchedCount > 0 && <span className="match-stat unmatched">⚠ {unmatchedCount} extra</span>}
              {unmappedRevisions.length > 0 && <span className="match-stat context-matched">📌 {unmappedRevisions.length}</span>}
              <button className="btn-match-info" onClick={() => setShowMatchInfo(v => !v)}>
                {showMatchInfo ? 'Hide' : 'Details'}
              </button>
            </div>
            {showMatchInfo && (
              <div className="match-details-panel">
                {matchDetails.map((d) => (
                  <div key={d.rowIndex} className={`match-detail-row ${d.matched ? 'text' : 'none'}`}>
                    <span className="match-detail-score">#{d.rowIndex + 1}</span>
                    <span className="match-detail-valid">{d.isValid ? '✔' : '✗'}</span>
                    <span className="match-detail-text" title={d.excelText}>
                      {d.excelText.length > 50 ? d.excelText.substring(0, 50) + '...' : d.excelText}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* ─── Single Revision Card (one at a time) ─── */}
      {totalCount === 0 ? (
        <div className="no-changes">
          {allTrackChangesCount > 0 ? (
            <p>No track changes match the current filter.</p>
          ) : (
            <>
              <p>No track changes found.</p>
              <p className="hint">Upload a DOCX file to see revisions here.</p>
            </>
          )}
        </div>
      ) : (
        <div className="revision-navigator">
          {/* Navigation controls */}
          <div className="nav-controls">
            <button className="nav-btn" onClick={() => goTo(currentRevisionIndex - 1)} disabled={currentRevisionIndex <= 0} title="Previous">◀</button>
            <span className="nav-position">{currentRevisionIndex + 1} / {totalCount}</span>
            <button className="nav-btn" onClick={() => goTo(currentRevisionIndex + 1)} disabled={currentRevisionIndex >= totalCount - 1} title="Next">▶</button>
            <button className="nav-btn nav-skip" onClick={goToNextIncomplete} title="Next incomplete">⏭</button>
          </div>

          {/* Current revision card */}
          {currentChange && (
            <div className={`revision-card ${getTypeClass(currentChange.type)} ${currentStatus === 'complete' ? 'card-complete' : ''}`}>
              <div className="revision-status-row">
                <span className={`revision-status-badge status-${currentStatus}`}>
                  {currentStatus === 'complete' ? '✅ Complete' : currentStatus === 'skipped' ? '⏭ Skipped' : '⏳ Pending'}
                </span>
                {currentChange.id in validationMap && (
                  <span className={`validity-badge ${validationMap[currentChange.id] ? 'valid' : 'invalid'}`}>
                    {validationMap[currentChange.id] ? '✓ Valid' : '✗ Invalid'}
                  </span>
                )}
              </div>

              <div className="revision-type-row">
                <span className="change-icon">{getTypeIcon(currentChange.type)}</span>
                <span className="change-type">{currentChange.type}</span>
                <span className="change-author">{currentChange.author}</span>
              </div>

              <div className="revision-text">{currentChange.text}</div>

              {currentChange.date && (
                <div className="revision-meta">{formatDate(currentChange.date)} · Para {currentChange.paragraphIndex + 1}</div>
              )}

              {currentChange.id in metaMap && (
                <div className="revision-meta-actions">
                  <button className={`btn-meta ${activePopover?.type === 'reason' ? 'active' : ''}`} onClick={() => setActivePopover(activePopover?.type === 'reason' ? null : { type: 'reason' })}>💡 Reason</button>
                  <button className={`btn-meta ${activePopover?.type === 'suggestedFix' ? 'active' : ''}`} onClick={() => setActivePopover(activePopover?.type === 'suggestedFix' ? null : { type: 'suggestedFix' })}>🔧 Fix</button>
                </div>
              )}

              {activePopover && currentChange.id in metaMap && (
                <div className="meta-popover">
                  <div className="meta-popover-title">{activePopover.type === 'reason' ? '💡 Reason' : '🔧 Suggested Fix'}</div>
                  <div className="meta-popover-content">
                    {activePopover.type === 'reason' ? (metaMap[currentChange.id]?.reason || 'No reason') : (metaMap[currentChange.id]?.suggestedFix || 'No fix')}
                  </div>
                </div>
              )}

              <div className="revision-actions">
                <button className="btn-mark-complete" onClick={() => onMarkComplete(currentRevisionIndex)} disabled={currentStatus === 'complete'}>✅ Mark Complete</button>
                <button className="btn-mark-skip" onClick={() => onMarkSkipped(currentRevisionIndex)} disabled={currentStatus === 'skipped'}>⏭ Skip</button>
              </div>
            </div>
          )}

          {/* Mini completion dots */}
          <div className="revision-dots">
            {trackChanges.slice(0, Math.min(trackChanges.length, 50)).map((_, idx) => {
              const st = revisionStatuses[String(idx)] || 'pending';
              return (
                <div key={idx} className={`dot dot-${st} ${idx === currentRevisionIndex ? 'dot-active' : ''}`} onClick={() => goTo(idx)} title={`#${idx + 1} — ${st}`} />
              );
            })}
            {trackChanges.length > 50 && <span className="dots-overflow">+{trackChanges.length - 50}</span>}
          </div>
        </div>
      )}
    </div>
  );
};

export default TrackChangesPanel;
