import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
import type { TrackChange } from '../types';
import './PdfViewer.css';

// Set up PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const API_URL = '';

interface Props {
  selectedChange: TrackChange | null;
  onTextSearch: (text: string) => void;
  docxFile: File | null;
  sessionPdfUrl?: string | null;
  sessionId?: string | null;
}

/** Match result from fuzzy PDF page matching */
interface PageMatch {
  pageNumber: number;
  score: number;
  matchStrategy: string;
  matchedText: string;
  pageTextPreview: string;
  details: {
    contextScore: number;
    paragraphScore: number;
    wordOverlap: number;
    adjacentBonus: number;
  };
}

interface TextItem {
  str: string;
  transform: number[];
}

/** Normalize whitespace and lowercase for comparison */
function normalizeText(text: string): string {
  return (text || '').replace(/\s+/g, ' ').trim().toLowerCase();
}

/**
 * Fuzzy "contains" scorer — measures how well `search` appears within `target`.
 * Returns 0–100.
 */
function fuzzyContainsScore(search: string, target: string): number {
  if (!search || search.length < 3 || !target) return 0;
  if (target.includes(search)) return 100;

  const halfLen = Math.floor(search.length / 2);
  if (halfLen > 5) {
    const first = search.substring(0, halfLen);
    const second = search.substring(halfLen);
    if (target.includes(first) && target.includes(second)) return 85;
    if (target.includes(first) || target.includes(second)) return 55;
  }

  const words = search.split(/\s+/).filter((w) => w.length > 2);
  if (words.length === 0) return 0;

  let matched = 0;
  let consecutiveMax = 0;
  let cur = 0;
  let lastEnd = -1;

  for (const w of words) {
    const idx = target.indexOf(w, Math.max(0, lastEnd));
    if (idx >= 0) {
      matched++;
      if (lastEnd >= 0 && idx <= lastEnd + 80) {
        cur++;
        consecutiveMax = Math.max(consecutiveMax, cur);
      } else {
        cur = 1;
      }
      lastEnd = idx + w.length;
    } else {
      if (target.indexOf(w) >= 0) matched++;
      cur = 0;
    }
  }

  const wordRatio = matched / words.length;
  const seqBonus = words.length > 1 ? consecutiveMax / words.length : 0;
  return Math.min(100, wordRatio * 50 + seqBonus * 30);
}

/**
 * Fuzzy-match a track change against all PDF pages.
 * Returns the top-5 page candidates with detailed scoring.
 */
async function findTextInPdfFuzzy(
  pdfDoc: any,
  change: TrackChange
): Promise<PageMatch[]> {
  const numPages = pdfDoc.numPages;

  // 1. Extract text from every page
  const pages: { n: number; text: string }[] = [];
  for (let i = 1; i <= numPages; i++) {
    const pg = await pdfDoc.getPage(i);
    const tc = await pg.getTextContent();
    const t = tc.items
      .filter((it: any) => 'str' in it)
      .map((it: TextItem) => it.str)
      .join(' ')
      .replace(/\s+/g, ' ');
    pages.push({ n: i, text: t });
  }

  // 2. Build search signals from track change context
  const changeText = normalizeText(change.text);
  const ctxText = normalizeText(
    (change.prevContext || '') + ' ' + change.text + ' ' + (change.postContext || '')
  );
  const paraText = normalizeText(change.paragraphText || '');
  const prevPara = normalizeText(change.previousPara || '');
  const postPara = normalizeText(change.postPara || '');

  // 3. Score every page using multiple signals
  const scored: PageMatch[] = [];

  for (const { n, text } of pages) {
    const low = text.toLowerCase();

    const contextScore = ctxText.length > 5 ? fuzzyContainsScore(ctxText, low) : 0;
    const paragraphScore = paraText.length > 5 ? fuzzyContainsScore(paraText, low) : 0;

    const allWords = (ctxText + ' ' + paraText).split(/\s+/).filter((w) => w.length > 3);
    const uniq = [...new Set(allWords)];
    const wordOverlap =
      uniq.length > 0
        ? (uniq.filter((w) => low.includes(w)).length / uniq.length) * 100
        : 0;

    let adjacentBonus = 0;
    const checkAdj = (p: string, full: number, partial: number) => {
      if (p.length < 10) return;
      const snip = p.substring(0, Math.min(60, p.length));
      if (low.includes(snip)) { adjacentBonus += full; return; }
      const ws = snip.split(/\s+/).filter((w) => w.length > 3);
      const m = ws.filter((w) => low.includes(w)).length;
      if (ws.length > 0 && m / ws.length > 0.5) adjacentBonus += partial;
    };
    checkAdj(prevPara, 15, 8);
    checkAdj(postPara, 15, 8);

    const score = Math.min(
      100,
      contextScore * 0.35 + paragraphScore * 0.30 + wordOverlap * 0.20 + adjacentBonus
    );

    let matchStrategy = 'fuzzy-words';
    if (contextScore === 100) matchStrategy = 'exact-context';
    else if (paragraphScore === 100) matchStrategy = 'exact-paragraph';
    else if (low.includes(changeText) && changeText.length > 5) matchStrategy = 'exact-text';
    else if (wordOverlap > 70) matchStrategy = 'word-overlap';
    else if (contextScore > 50 || paragraphScore > 50) matchStrategy = 'partial-match';

    if (score > 5) {
      scored.push({
        pageNumber: n,
        score: Math.round(score * 10) / 10,
        matchStrategy,
        matchedText: changeText.substring(0, 60),
        pageTextPreview: text.substring(0, 120).trim(),
        details: {
          contextScore: Math.round(contextScore),
          paragraphScore: Math.round(paragraphScore),
          wordOverlap: Math.round(wordOverlap),
          adjacentBonus: Math.round(adjacentBonus),
        },
      });
    }
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 5);
}

const PdfViewer: React.FC<Props> = ({ selectedChange, onTextSearch, docxFile, sessionPdfUrl, sessionId }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [numPages, setNumPages] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [highlightText, setHighlightText] = useState<string | null>(null);
  const [scale, setScale] = useState<number>(1.2);
  const [topPageMatches, setTopPageMatches] = useState<PageMatch[]>([]);
  const [matchingInProgress, setMatchingInProgress] = useState(false);
  const [directPdfFile, setDirectPdfFile] = useState<File | null>(null);
  const [pdfFileName, setPdfFileName] = useState<string | null>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const pageRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const [selectionInfo, setSelectionInfo] = useState<{ text: string } | null>(null);

  // Handle direct PDF upload (skip conversion)
  const handleDirectPdfUpload = useCallback((file: File) => {
    if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    const url = URL.createObjectURL(file);
    setDirectPdfFile(file);
    setPdfFileName(file.name);
    setPdfUrl(url);
    setPdfLoading(false);
    setPdfError(null);
  }, [pdfUrl]);

  const handlePdfInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      handleDirectPdfUpload(file);
    }
    e.target.value = '';
  };

  // Load PDF from session URL if available (skip conversion on resume)
  useEffect(() => {
    if (!sessionPdfUrl) return;
    if (directPdfFile) return; // user uploaded a PDF manually, keep that
    setPdfLoading(true);
    setPdfError(null);
    fetch(sessionPdfUrl)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load session PDF');
        return res.blob();
      })
      .then((blob) => {
        if (pdfUrl) URL.revokeObjectURL(pdfUrl);
        const url = URL.createObjectURL(blob);
        setPdfUrl(url);
        setPdfLoading(false);
      })
      .catch((err) => {
        setPdfError(err.message);
        setPdfLoading(false);
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionPdfUrl]);

  // Convert DOCX to PDF when file is uploaded (only if no session PDF)
  useEffect(() => {
    if (!docxFile) {
      if (!directPdfFile) setPdfUrl(null);
      return;
    }
    if (directPdfFile) return;
    if (sessionPdfUrl) return; // Already have a PDF from session, skip conversion

    setPdfLoading(true);
    setPdfError(null);

    const formData = new FormData();
    formData.append('file', docxFile);
    if (sessionId) {
      formData.append('session_id', sessionId);
    }

    fetch(`${API_URL}/api/convert-to-pdf`, {
      method: 'POST',
      body: formData,
    })
      .then((res) => {
        if (!res.ok) throw new Error('PDF conversion failed');
        return res.blob();
      })
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        setPdfUrl(url);
        setPdfLoading(false);
      })
      .catch((err) => {
        setPdfError(err.message);
        setPdfLoading(false);
      });

    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [docxFile, sessionPdfUrl]);

  // Navigate to track change in PDF using fuzzy multi-signal matching
  useEffect(() => {
    if (!selectedChange || !pdfDoc) return;

    setMatchingInProgress(true);
    setTopPageMatches([]);

    findTextInPdfFuzzy(pdfDoc, selectedChange)
      .then((matches) => {
        setTopPageMatches(matches);
        setMatchingInProgress(false);

        if (matches.length > 0) {
          const best = matches[0];
          setCurrentPage(best.pageNumber);
          setHighlightText(best.matchedText);

          setTimeout(() => {
            const pageEl = pageRefs.current.get(best.pageNumber);
            if (pageEl) {
              pageEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }, 100);

          setTimeout(() => {
            highlightInTextLayer(best.matchedText, best.pageNumber);
          }, 300);
        }
      })
      .catch(() => {
        setMatchingInProgress(false);
      });
  }, [selectedChange, pdfDoc]);

  const highlightInTextLayer = (text: string, pageNum: number) => {
    document.querySelectorAll('.pdf-text-highlight').forEach((el) => {
      el.classList.remove('pdf-text-highlight');
    });

    if (!containerRef.current || !text) return;

    const pageEl = pageRefs.current.get(pageNum);
    if (!pageEl) return;

    const textLayerSpans = pageEl.querySelectorAll('.react-pdf__Page__textContent span');
    const searchLower = text.toLowerCase().slice(0, 40);

    for (const span of textLayerSpans) {
      const spanText = (span.textContent || '').toLowerCase();
      if (spanText && searchLower.includes(spanText) && spanText.length > 2) {
        span.classList.add('pdf-text-highlight');
      }
    }
  };

  const onDocumentLoadSuccess = useCallback(({ numPages: total }: { numPages: number }) => {
    setNumPages(total);
  }, []);

  const onPdfLoadSuccess = useCallback((pdf: any) => {
    setPdfDoc(pdf);
  }, []);

  const handlePageSuggestionClick = (pageNum: number, matchText: string) => {
    setCurrentPage(pageNum);
    setHighlightText(matchText);

    setTimeout(() => {
      const pageEl = pageRefs.current.get(pageNum);
      if (pageEl) {
        pageEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);

    setTimeout(() => {
      highlightInTextLayer(matchText, pageNum);
    }, 300);
  };

  // Auto-search: fire PXML search when text is selected on PDF
  useEffect(() => {
    if (!selectionInfo) return;
    const timer = setTimeout(() => {
      onTextSearch(selectionInfo.text);
    }, 300);
    return () => clearTimeout(timer);
  }, [selectionInfo, onTextSearch]);

  // Listen for text selection via mouse drag on the PDF canvas
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseUp = () => {
      setTimeout(() => {
        const sel = window.getSelection();
        const text = sel?.toString().trim();

        if (!text || text.length < 5) return;
        if (!sel?.anchorNode) return;

        const anchor = sel.anchorNode instanceof HTMLElement
          ? sel.anchorNode
          : sel.anchorNode.parentElement;
        if (!anchor) return;

        const isInContainer = container.contains(anchor);
        const isInPdfPage = !!anchor.closest('.react-pdf__Page__textContent');
        if (!isInContainer && !isInPdfPage) return;

        // Highlight selected spans
        container.querySelectorAll('.pdf-selection-highlight').forEach((el) => {
          el.classList.remove('pdf-selection-highlight');
        });
        const rangeObj = sel.getRangeAt(0);
        const textLayers = container.querySelectorAll('.react-pdf__Page__textContent');
        textLayers.forEach((tl) => {
          const spans = tl.querySelectorAll('span');
          spans.forEach((span) => {
            if (rangeObj.intersectsNode(span)) {
              span.classList.add('pdf-selection-highlight');
            }
          });
        });

        setSelectionInfo({ text });
      }, 50);
    };

    container.addEventListener('mouseup', handleMouseUp);
    return () => { container.removeEventListener('mouseup', handleMouseUp); };
  }, [pdfUrl, directPdfFile]);

  if (!docxFile && !directPdfFile) {
    return (
      <div className="pdf-viewer">
        <div className="pdf-toolbar">
          <span className="pdf-toolbar-title">PDF Viewer</span>
        </div>
        <div className="viewer-empty">
          <div className="empty-icon">📄</div>
          <p>Upload a DOCX file to view its content as PDF</p>
          <p className="empty-or">— or —</p>
          <button
            className="btn-upload-pdf"
            onClick={() => pdfInputRef.current?.click()}
          >
            📎 Upload PDF directly
          </button>
          <input
            ref={pdfInputRef}
            type="file"
            accept=".pdf"
            onChange={handlePdfInputChange}
            hidden
          />
        </div>
      </div>
    );
  }

  return (
    <div className="pdf-viewer">
      <div className="pdf-toolbar">
        <div className="pdf-toolbar-left">
          <span className="pdf-toolbar-title">📄 {pdfFileName || docxFile?.name || 'Document'}</span>
          <button
            className="btn-toolbar-pdf-upload"
            onClick={() => pdfInputRef.current?.click()}
            title="Upload a PDF directly (replaces current view)"
          >
            📎 PDF
          </button>
          <input
            ref={pdfInputRef}
            type="file"
            accept=".pdf"
            onChange={handlePdfInputChange}
            hidden
          />
        </div>
        <div className="pdf-toolbar-center">
          <button
            className="pdf-nav-btn"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
          >
            ◀
          </button>
          <span className="pdf-page-info">
            Page {currentPage} of {numPages}
          </span>
          <button
            className="pdf-nav-btn"
            onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))}
            disabled={currentPage >= numPages}
          >
            ▶
          </button>
        </div>
        <div className="pdf-toolbar-right">
          <button className="pdf-zoom-btn" onClick={() => setScale((s) => Math.max(0.5, s - 0.1))}>−</button>
          <span className="pdf-zoom-info">{Math.round(scale * 100)}%</span>
          <button className="pdf-zoom-btn" onClick={() => setScale((s) => Math.min(3, s + 0.1))}>+</button>
        </div>
      </div>

      {/* Page Suggestions — top 5 fuzzy-matched pages */}
      {selectedChange && (topPageMatches.length > 0 || matchingInProgress) && (
        <div className="page-suggestions-panel">
          <div className="page-suggestions-header">
            <span className="page-suggestions-title">
              🔍 Top Page Matches
            </span>
            {matchingInProgress && <span className="matching-spinner">⏳ matching...</span>}
            <button
              className="page-suggestions-close"
              onClick={() => setTopPageMatches([])}
            >
              ✕
            </button>
          </div>
          <div className="page-suggestions-list">
            {topPageMatches.map((match, idx) => (
              <div
                key={match.pageNumber}
                className={`page-suggestion-item ${idx === 0 ? 'best-match' : ''} ${
                  currentPage === match.pageNumber ? 'active' : ''
                }`}
                onClick={() =>
                  handlePageSuggestionClick(match.pageNumber, match.matchedText)
                }
                title={`Context: ${match.details.contextScore}% | Paragraph: ${match.details.paragraphScore}% | Words: ${match.details.wordOverlap}% | Adjacent: ${match.details.adjacentBonus}%`}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span className="suggestion-rank">#{idx + 1}</span>
                  <span className="suggestion-page">Page {match.pageNumber}</span>
                  <span
                    className={`suggestion-score ${
                      match.score > 70 ? 'high' : match.score > 40 ? 'medium' : 'low'
                    }`}
                  >
                    {match.score}%
                  </span>
                </div>
                <span className="suggestion-strategy">{match.matchStrategy}</span>
                <div className="suggestion-details">
                  <span title="Context match">C:{match.details.contextScore}</span>
                  <span title="Paragraph match">P:{match.details.paragraphScore}</span>
                  <span title="Word overlap">W:{match.details.wordOverlap}</span>
                  <span title="Adjacent bonus">A:{match.details.adjacentBonus}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="pdf-canvas" ref={containerRef}>
        {/* Selection search indicator */}
        {selectionInfo && (
          <div className="selection-search-popup">
            <span className="selection-search-icon">🔍</span>
            <div className="selection-preview">
              Searching: &quot;{selectionInfo.text.length > 80
                ? selectionInfo.text.substring(0, 80) + '...'
                : selectionInfo.text}&quot;
            </div>
            <button
              className="btn-search-pxml"
              onClick={() => {
                setSelectionInfo(null);
                window.getSelection()?.removeAllRanges();
                containerRef.current?.querySelectorAll('.pdf-selection-highlight').forEach((el) => {
                  el.classList.remove('pdf-selection-highlight');
                });
              }}
            >
              ✕
            </button>
          </div>
        )}

        {pdfLoading && (
          <div className="pdf-loading">
            <div className="loading-spinner" />
            <p>Converting document to PDF via MS Word...</p>
          </div>
        )}

        {pdfError && (
          <div className="pdf-error">
            <p>⚠️ {pdfError}</p>
            <p className="pdf-error-hint">Make sure the backend is running and MS Word is installed.</p>
          </div>
        )}

        {pdfUrl && (
          <Document
            file={pdfUrl}
            onLoadSuccess={(pdf) => {
              onDocumentLoadSuccess(pdf);
              onPdfLoadSuccess(pdf);
            }}
            loading={
              <div className="pdf-loading">
                <div className="loading-spinner" />
                <p>Loading PDF...</p>
              </div>
            }
          >
            {Array.from({ length: numPages }, (_, i) => i + 1).map((pageNum) => (
              <div
                key={pageNum}
                className={`pdf-page-wrapper ${pageNum === currentPage ? 'current-page' : ''}`}
                ref={(el) => {
                  if (el) pageRefs.current.set(pageNum, el);
                }}
              >
                <Page
                  pageNumber={pageNum}
                  scale={scale}
                  renderTextLayer={true}
                  renderAnnotationLayer={true}
                />
                <div className="pdf-page-number">Page {pageNum}</div>
              </div>
            ))}
          </Document>
        )}
      </div>
    </div>
  );
};

export default PdfViewer;
