import React, { useEffect, useRef, useState } from 'react';
import type { DocxParagraph, TrackChange } from '../types';
import './DocxViewer.css';

interface Props {
  paragraphs: DocxParagraph[];
  selectedChange: TrackChange | null;
  onParagraphClick: (paragraphIndex: number) => void;
}

const DocxViewer: React.FC<Props> = ({ paragraphs, selectedChange, onParagraphClick }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const highlightedRef = useRef<HTMLSpanElement>(null);
  const [clickedParagraph, setClickedParagraph] = useState<number | null>(null);

  useEffect(() => {
    if (selectedChange && highlightedRef.current) {
      highlightedRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [selectedChange]);

  if (paragraphs.length === 0) {
    return (
      <div className="docx-viewer">
        <div className="panel-header">
          <h3>Document Viewer</h3>
        </div>
        <div className="viewer-empty">
          <div className="empty-icon">DOC</div>
          <p>Upload a DOCX file to view its content</p>
        </div>
      </div>
    );
  }

  return (
    <div className="docx-viewer">
      <div className="panel-header">
        <h3>Document Viewer</h3>
      </div>
      <div className="viewer-content" ref={containerRef}>
        {paragraphs.map((paragraph) => (
          <p
            key={paragraph.id}
            className={`docx-paragraph ${clickedParagraph === paragraph.paragraphIndex ? 'paragraph-active' : ''}`}
            id={`para-${paragraph.paragraphIndex}`}
            onClick={() => {
              setClickedParagraph(paragraph.paragraphIndex);
              onParagraphClick(paragraph.paragraphIndex);
            }}
          >
            {paragraph.runs.length === 0 ? (
              <span className="empty-para">&nbsp;</span>
            ) : (
              paragraph.runs.map((run) => {
                const isHighlighted =
                  selectedChange !== null &&
                  run.trackChangeId === selectedChange.id;

                return (
                  <span
                    key={run.id}
                    ref={isHighlighted ? highlightedRef : undefined}
                    className={`docx-run ${run.type} ${isHighlighted ? 'highlighted' : ''}`}
                    title={
                      run.author
                        ? `${run.type} by ${run.author}${run.date ? ' on ' + new Date(run.date).toLocaleDateString() : ''}`
                        : undefined
                    }
                  >
                    {run.text}
                  </span>
                );
              })
            )}
          </p>
        ))}
      </div>
    </div>
  );
};

export default DocxViewer;
